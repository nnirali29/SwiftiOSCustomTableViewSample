//
//  CustomFruitCell.swift
//  TableviewSample
//
//  Created by CSCI5737 Fall19 on 10/3/19.
//  Copyright © 2019 UHCL. All rights reserved.
//

import UIKit

class CustomFruitCell: UITableViewCell {

    @IBOutlet weak var lblMain: UILabel!
    @IBOutlet weak var lblSub: UILabel!
    @IBOutlet weak var imgFruitImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
